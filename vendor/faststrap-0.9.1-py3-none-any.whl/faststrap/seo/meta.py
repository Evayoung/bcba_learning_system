"""SEO meta tags generation.

Provides the SEO component for comprehensive meta tag generation including
Open Graph, Twitter Cards, and basic SEO meta tags.
"""

from __future__ import annotations

import warnings
from typing import Any, Literal

from fasthtml.common import Link, Meta, Title


def SEO(
    title: str | None = None,
    description: str | None = None,
    keywords: list[str] | None = None,
    image: str | None = None,
    url: str | None = None,
    og_type: Literal["website", "article", "product"] = "website",
    # Article-specific
    article: bool = False,
    published_time: str | None = None,
    modified_time: str | None = None,
    author: str | None = None,
    section: str | None = None,
    tags: list[str] | None = None,
    # Twitter-specific
    twitter_card: Literal[
        "summary", "summary_large_image", "app", "player"
    ] = "summary_large_image",
    twitter_site: str | None = None,
    twitter_creator: str | None = None,
    # Advanced
    robots: str = "index, follow",
    canonical: str | None = None,
    locale: str | None = None,
    alternate_locales: list[str] | None = None,
    **kwargs: Any,
) -> tuple[Any, ...]:
    """Generate comprehensive SEO meta tags.

    Creates meta tags for basic SEO, Open Graph, and Twitter Cards.

    Args:
        title: Page title (also used for og:title and twitter:title)
        description: Page description (also used for og:description)
        keywords: List of keywords for meta keywords tag
        image: Image URL for social sharing (og:image, twitter:image)
        url: Canonical URL for the page (og:url)
        og_type: Open Graph type (website, article, product)
        article: If True, adds article-specific meta tags
        published_time: Article published time (ISO 8601 format)
        modified_time: Article modified time (ISO 8601 format)
        author: Article author name
        section: Article section/category
        tags: Article tags
        twitter_card: Twitter card type
        twitter_site: Twitter site handle (@username)
        twitter_creator: Twitter creator handle (@username)
        robots: Robots meta tag value
        canonical: Canonical URL (if different from url)
        locale: Page locale (e.g., "en_US")
        alternate_locales: List of alternate locales
        **kwargs: Additional meta tags as key-value pairs

    Returns:
        Tuple of meta tag elements to include in page head

    Examples:
        Basic usage:
        >>> SEO(
        ...     title="My Page - Site Name",
        ...     description="Page description",
        ...     image="/assets/og-image.jpg"
        ... )

        Article page:
        >>> SEO(
        ...     title="Blog Post Title",
        ...     description="Post excerpt",
        ...     image="/assets/post-image.jpg",
        ...     article=True,
        ...     published_time="2026-02-12T10:00:00Z",
        ...     author="John Doe",
        ...     tags=["python", "fasthtml"]
        ... )

    Note:
        - Title, description, and image are used for both basic meta tags and social sharing
        - If article=True, type is automatically set to "article"
        - Canonical URL defaults to url parameter if not explicitly set
    """
    elements: list[Any] = []

    legacy_type = kwargs.pop("type", None)
    if legacy_type is not None:
        warnings.warn(
            "SEO(type=...) is deprecated; use SEO(og_type=...) instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        if og_type == "website":
            og_type = legacy_type

    # Basic meta tags
    if title:
        elements.append(Title(title))

    if description:
        elements.append(Meta(name="description", content=description))

    if keywords:
        elements.append(Meta(name="keywords", content=", ".join(keywords)))

    if robots:
        elements.append(Meta(name="robots", content=robots))

    # Canonical URL
    canonical_url = canonical or url
    if canonical_url:
        elements.append(Link(rel="canonical", href=canonical_url))

    # Open Graph tags
    has_og_content = any(
        [
            title,
            description,
            image,
            url,
            locale,
            alternate_locales,
            article,
            published_time,
            modified_time,
            author,
            section,
            tags,
        ]
    )

    if title:
        elements.append(Meta(property="og:title", content=title))

    if description:
        elements.append(Meta(property="og:description", content=description))

    if image:
        elements.append(Meta(property="og:image", content=image))

    if url:
        elements.append(Meta(property="og:url", content=url))

    # Set type to article if article=True
    resolved_og_type = "article" if article else og_type
    if has_og_content:
        elements.append(Meta(property="og:type", content=resolved_og_type))

    if locale:
        elements.append(Meta(property="og:locale", content=locale))

    if alternate_locales:
        for alt_locale in alternate_locales:
            elements.append(Meta(property="og:locale:alternate", content=alt_locale))

    # Article-specific tags
    if article or resolved_og_type == "article":
        if published_time:
            elements.append(Meta(property="article:published_time", content=published_time))

        if modified_time:
            elements.append(Meta(property="article:modified_time", content=modified_time))

        if author:
            elements.append(Meta(property="article:author", content=author))

        if section:
            elements.append(Meta(property="article:section", content=section))

        if tags:
            for tag in tags:
                elements.append(Meta(property="article:tag", content=tag))

    # Twitter Card tags
    has_twitter_content = any([title, description, image, twitter_site, twitter_creator])
    if has_twitter_content:
        elements.append(Meta(name="twitter:card", content=twitter_card))

    if title:
        elements.append(Meta(name="twitter:title", content=title))

    if description:
        elements.append(Meta(name="twitter:description", content=description))

    if image:
        elements.append(Meta(name="twitter:image", content=image))

    if twitter_site:
        elements.append(Meta(name="twitter:site", content=twitter_site))

    if twitter_creator:
        elements.append(Meta(name="twitter:creator", content=twitter_creator))

    # Additional custom meta tags
    for key, value in kwargs.items():
        if value is not None:
            # Convert underscores to hyphens for attribute names
            attr_name = key.replace("_", "-")
            elements.append(Meta(name=attr_name, content=str(value)))

    return tuple(elements)
